# Debug Docker 
    To run it docker-compose up form the root dir of docker-compose.yml to the project
```
## Author
Navin

## License
Licensed under MIT
